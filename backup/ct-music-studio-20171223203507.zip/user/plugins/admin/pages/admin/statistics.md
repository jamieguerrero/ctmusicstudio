---
title: Statistics

access:
    admin.statistics: true
    admin.super: true
---
