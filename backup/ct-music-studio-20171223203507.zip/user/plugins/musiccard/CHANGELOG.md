# v1.2.3
## 06/14/2016

1. [](#improved)
    * Created CHANGELOG.md

# v1.2.2
## 06/13/2016

1. [](#improved)
    * Removed mptre's SoundCloud PHP library, as it is no longer needed.

# v1.2.1
## 06/08/2016 

1. [](#improved)
    * Removed FontAwesome requirement. Logo icons now load from included custom font files.

# v1.2
## 06/07/2016

1. [](#new)
    * Added Bandcamp support.
    * Added the BCScraper PHP class. This scrapes for metadata from a Bandcamp link.

2. [](!improved)
    * Added Bandcamp logo font icon.

# v1.1
## 06/07/2016

1. [](#new)
    * Added SoundCloud support.
    * mptre's SoundCloud PHP library is now autoloaded via Composer.
    * Logo of source is now displayed in bottom-right corner of card.

# v1.0
## 06/02/2016

1. [](#improved)
    * Moved Spotify application credentials to blueprints.yaml.

# v0.8.6
## 06/02/2016

1. [](#bugfix)
    * Fixed composer autoload reference.

# v0.8.5
## 06/02/2016

1. [](#improved)
    * jwilsson's Spotify Web API PHP library is now autoloaded via Composer.
    * Removed Autoloader class

# v0.8
## 06/02/2016

1. [](#new)
    * This is the first beta release.
