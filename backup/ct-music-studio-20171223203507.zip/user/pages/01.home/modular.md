---
title: home
content:
    items: '@self.modular'
    order:
        by: default
        dir: asc
        custom:
            - _thestudio
            - _thelessons
            - _theservices
menu: home
onpage_menu: true
---
