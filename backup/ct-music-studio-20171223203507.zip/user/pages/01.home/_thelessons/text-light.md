---
title: ''
media_order: ''
body_classes: ''
order_by: ''
order_manual: ''
---

# [the lessons](/services#lessons)

## studio hours 
<div class="schedule">
  <div class="sched-row">
    <p class="sched-date">MONDAY</p>
    <p class="sched-time">9AM-5PM</p>
  </div>
  <div class="sched-row sched-dark">
    <p class="sched-date">TUESDAY</p>
    <p class="sched-time">9AM-5PM</p>
  </div>
  <div class="sched-row">
    <p class="sched-date">WEDNESDAY</p>
    <p class="sched-time">9AM-5PM</p>
  </div>
  <div class="sched-row sched-dark">
    <p class="sched-date">THURSDAY</p>
    <p class="sched-time">9AM-5PM</p>
  </div>
  <div class="sched-row">
    <p class="sched-date">FRIDAY</p>
    <p class="sched-time">9AM-5PM</p>
  </div>
  <div class="sched-row sched-dark">
    <p class="sched-date">SATURDAY</p>
    <p class="sched-time">9AM-5PM</p>
  </div>
  <div class="sched-row">
    <p class="sched-date">SUNDAY</p>
    <p class="sched-time">9AM-5PM</p>
  </div>
</div>
Great business ideas when utilized effectively can save lots of money. This is not only easy for those who work full-time as an advertiser, but also for those who work from home.
