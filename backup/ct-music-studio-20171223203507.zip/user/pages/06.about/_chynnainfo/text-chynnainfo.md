---
media_order: 'chynna-piano-smiling-edit.jpg,york.png,rcm.png,text-chynnainfo.html'
---

##chynna tolibas

Chynna Tolibas has been teaching for 10+ years and holds her ARCT (Piano Performance) from the Royal Conservatory of Music and Bachelor in Arts with a Certificate in Digital Media from York University.

playing since -influenced by ————>>>>>> background —> diverse. <— cuz it should has
