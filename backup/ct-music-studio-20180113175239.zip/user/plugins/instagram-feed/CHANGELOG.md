# v1.0.0
##  11/16/2016

2. Instagram Removed the '/media' route
    * First of all thanks to @Bussmeyer for the Pull Request
    * Fixed the API Call 
    * Included Basic support for the old Template Syntax
    * If your cutom template does not work anymore, please have look at `https://www.instagram.com/username/?__a=1` (replace username with your username) and look for your missing datas


1. [](#new)
    * Just started the project.
