#!/bin/sh
gosass -input scss/ -output css/ -sourcemap -watch -style compressed
