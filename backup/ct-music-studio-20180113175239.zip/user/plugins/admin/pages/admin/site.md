---
title: Site Settings
template: config
access:
    admin.settings: true
    admin.super: true
---
