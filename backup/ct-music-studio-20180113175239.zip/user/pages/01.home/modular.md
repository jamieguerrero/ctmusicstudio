---
title: home
content:
    items: '@self.modular'
    order:
        by: default
        dir: asc
        custom:
            - _thestudio
            - _chynnainfo
            - _theservices
            - _portal
            - _contact

menu: home
onpage_menu: true
---
