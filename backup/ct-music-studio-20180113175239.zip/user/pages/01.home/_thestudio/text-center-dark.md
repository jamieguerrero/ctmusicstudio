---
title: _thestudio
---

# the studio

Chynna Tolibas has worked with music studios across the GTA for nearly 10 years before deciding to focus on her own private space. **ct music studio** is eponymous not only based on Chynna's initials, but it also serves as a tribute for her late father and her 3 elder siblings whose names also begin with C.

Built in-home, **ct music studio** was designed to provide a comfortable space to learn, explore, and create. With a variety of instruments and tools readily available to work with, anyone can bring their interests and passions to life. 
