---
title: _chynnainfo
media_order: 'chynna-piano-smiling-edit.jpg,york.png,rcm.png,text-chynnainfo.html'
---

#chynna tolibas

Chynna grew up surrounded by music. Born into a family of six, her parents and older siblings constantly exposed Chynna to a wide spectrum of musical genres. At the age of 7, her parents enrolled her in piano lessons. She has since studied under multiple private teachers, who have helped her establish her foundation with classical music. After receiving her Associate’s Diploma in Piano Performance (ARCT) with the Royal Conservatory of Music, she pursued her Spec. Honours BFA in Music at York University, where she used the creative freedom and space to explore other aspects of music such as jazz and composition. Alongside her musical growth Chynna also has a Cross-Disciplinary Certificate in Digital Media from York University.
