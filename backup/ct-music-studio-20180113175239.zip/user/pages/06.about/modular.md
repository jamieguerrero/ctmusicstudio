---
title: about
content:
    items: '@self.modular'
    order:
        by: default
        dir: asc
        custom:
            - _studioinfo
            - _chynnainfo
published: false
menu: about
onpage_menu: true
---

