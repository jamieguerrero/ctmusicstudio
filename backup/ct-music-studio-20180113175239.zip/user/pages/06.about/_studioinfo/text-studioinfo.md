---
title: '_studioinfo'
---

##studio info

CT Music Studio is located near David Suzuki Secondary School and other media school really close by. We rent studio space to burgeoning artists and stuff
