# v1.0.4
## 10/19/2016

1. [](#improved)
    * More complete README.md
    * Typo in Error template

# v1.0.3
## 09/16/2016

1. [](#bugfix)
    * Removed `Theme` from theme's class causing events to not process - https://github.com/getgrav/grav/issues/1047
    * Typo in README.md

# v1.0.2
## 07/20/2016

1. [](#bugfix)
    * Removed old `header.html.twig`
    
# v1.0.1
## 05/06/2016

1. [](#bugfix)
    * Fix for Grav 1.0.x

# v1.0.0
## 04/19/2016

1. [](#new)
    * ChangeLog started...
