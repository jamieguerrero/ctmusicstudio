<?php
namespace Grav\Plugin;

use Grav\Common\Plugin;

class DevToolsPlugin extends Plugin
{

}
